﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer8
{
    class Program
    {
        static void Main()
        {
            int a, b, x;
            string s;
            Console.Write("введите двузначное число ");
            s = Console.ReadLine();
            a = int.Parse(s);
            b = a % 100;
            //x = a / 10;
            Console.WriteLine("полученное число при перестановке = "  + b);
            Console.ReadLine();
        }
    }
}
