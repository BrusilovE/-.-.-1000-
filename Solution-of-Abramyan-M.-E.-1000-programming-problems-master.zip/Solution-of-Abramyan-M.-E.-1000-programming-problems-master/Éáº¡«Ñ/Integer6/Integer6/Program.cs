﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer6
{
    class Program
    {
        static void Main()
        {
            byte a;
            string s;
            Console.Write("Введите двузначное число ");
            s = Console.ReadLine();
            a = byte.Parse(s);
            Console.WriteLine("нахождение десятков = " + a / 10);
            Console.WriteLine("нахождение единиц = " + a % 10);
            Console.ReadLine();
        }
    }
}
