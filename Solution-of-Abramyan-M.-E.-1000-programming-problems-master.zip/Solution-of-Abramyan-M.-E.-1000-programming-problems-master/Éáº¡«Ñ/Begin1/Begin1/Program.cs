﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main()
        {
        int a = 2;
        int P;
        P = 4 * a;
        Console.WriteLine("периметр P = " + P);
        Console.ReadLine();
        }
    }

