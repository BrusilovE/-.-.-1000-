﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer7
{
    class Program
    {
        static void Main()
        {
            int a, sc, p;
            string s;
            Console.Write("введите двузначное число ");
            s = Console.ReadLine();
            a = byte.Parse(s);
            p = a / 10;
            sc = a % 10;
            Console.WriteLine("сумма его цифр = " + (p + sc));
            Console.WriteLine("произведение его цифр = " + p*sc);
            Console.ReadLine();

        }
    }
}
