﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main()
        {
        int a, V, S;
        a = 2;
        V = a * a * a;
        Console.WriteLine("Объем куба V= " + V);
        S = 6 * (a * a);
        Console.WriteLine("Площадь куба S= " + S);
        Console.ReadLine(); 
        }
    }

