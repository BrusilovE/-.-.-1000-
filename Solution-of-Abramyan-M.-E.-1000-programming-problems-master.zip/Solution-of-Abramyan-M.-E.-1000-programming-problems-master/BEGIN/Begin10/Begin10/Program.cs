﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
        double a, b;
        a = 3;
        b = 4;
        Console.WriteLine("сумма = " + (a + b));
        //Console.ReadLine();
        Console.WriteLine("разность = " + (a - b));
        Console.WriteLine("произведение = " + (a * b));
        Console.WriteLine("частное = " + (a / b));
        Console.ReadLine();
        }
    }

