﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Begin23
{
    class Program
    {
        static void Main(string[] args)
        {
            double A, B, C, t;
            string s;
            Console.WriteLine("Введите А");
            s = Console.ReadLine();
            A = double.Parse(s);

            Console.WriteLine("Введите B");
            s = Console.ReadLine();
            B = double.Parse(s);

            Console.WriteLine("Введите C");
            s = Console.ReadLine();
            C = double.Parse(s);

            t = A;
            A = B;
            B = C;
            C = t;

            Console.WriteLine("новые значения А = " + A);
            Console.WriteLine("новые значения B = " + B);
            Console.WriteLine("новые значения C = " + C);
            Console.ReadLine();
        }

    }
}
