﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Begin27
{
    class Program
    {
        static void Main(string[] args)
        {
            int A, A2;
            string s;
            Console.Write("введите число А = ");
            s = Console.ReadLine();
            A = int.Parse(s);

            A2 = A * A;
            A = A2 * A * A;
            //A8 = A4 * A * A;

            Console.WriteLine("степень числа A^2 = " + A2);
            Console.WriteLine("степень числа A^4 = " + A);
            //Console.WriteLine("степень числа A^8 = " + A8);
            Console.ReadLine();
        }
    }
}
