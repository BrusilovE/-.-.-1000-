﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
        int a, b, c, V, S;
        a = 2;
        b = 3;
        c = 4;
        V = a * b * c;
        Console.WriteLine("Объем V= " + V);
        S = 2 * (a * b + b * c + a * c);
        Console.WriteLine("Площать поверхности S= " + S);
        Console.ReadLine();
        }
    }

