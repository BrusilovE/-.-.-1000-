﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
        double a, b, S;
        a = 15;
        b = 10;
        S = (a + b) / 2;
        Console.WriteLine("Среднее арифметическое S= " + S);
        Console.ReadLine();
        }
    }

