﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Begin31
{
    class Program
    {
        static void Main()
        {
            int Tc, Tf;
            string s;
            Console.WriteLine("Введите значение температуры Т в градусах Фаренгейта ");
            s = Console.ReadLine();
            Tf = int.Parse(s);

            Tc = (Tf - 32) * 5/9;
            Console.WriteLine("Температура в градусах Цельсия равна " + Tc);
            Console.ReadLine();

        }
    }
}
