﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
        float a, b;
        string s;
        Console.WriteLine("введите 1-е  не нулевое число ");
        s = Console.ReadLine();
        a = float.Parse(s);

        Console.WriteLine("введите 2-е не нулевое число ");
        s = Console.ReadLine();
        b = float.Parse(s);

        Console.WriteLine("Сумма = " + Math.Abs(a + b));
        Console.WriteLine("Разность = " + Math.Abs(a - b));
        Console.WriteLine("Произведение = " + Math.Abs(a * b));
        Console.WriteLine("Частное = " + Math.Abs(a / b));
        Console.ReadLine();
    }
    }

