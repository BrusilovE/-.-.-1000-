﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
        const double pi = 3.14;  
        Double d, L;
        d = 5;
        L = pi * d;
        Console.WriteLine("Длина окружности L= " + L);
        Console.ReadLine();

        }
    }

