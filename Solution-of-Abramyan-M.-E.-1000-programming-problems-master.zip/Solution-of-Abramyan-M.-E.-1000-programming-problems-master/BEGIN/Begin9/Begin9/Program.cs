﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main()
        {
        double a, b, G;
        a = 8;
        b = 8;
        G = Math.Sqrt(a + b);
        Console.WriteLine("среднее геометрическое a и b равно " + G);
        Console.ReadLine();     
    }
    }

