﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main()
        {
        int a, b, S, P;
        a = 3;
        b = 5;
        S = a * b;
        Console.WriteLine("Площадь прямоугольника S= " + S);
        P = 2 * (a + b);
        Console.WriteLine("Периметр прямоугольника P= " + P);
        Console.ReadLine();
        }
    }

