﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
        const double pi = 3.14;
        double L, S, R;
        R = 3;
        L = 2 * pi * R;
        Console.WriteLine("Длина окружности L= " + L);
        S = pi * (R * R);
        Console.WriteLine("Площадь круга S= " + S);
        Console.ReadLine();
        }
    }

