﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Begin12
{
    class Program
    {
        static void Main()
        {
            double a, b, c;
            string s;
            Console.Write("введите сторону прямоугольника а = ");
            s = Console.ReadLine();
            a = double.Parse(s);

            Console.Write("введите сторону прямоугольника b = ");
            s = Console.ReadLine();
            b = double.Parse(s);

            c = Math.Sqrt(a * a + b * b);
            Console.WriteLine("гипотенуза равна " + c);
            Console.WriteLine("перимерт равен " + (a+b+c));

            Console.ReadLine();
        }
    }
}
