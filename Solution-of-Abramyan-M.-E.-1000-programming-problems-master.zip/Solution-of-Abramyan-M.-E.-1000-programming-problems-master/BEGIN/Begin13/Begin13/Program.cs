﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Begin13
{
    class Program
    {
        static void Main(string[] args)
        {
            double r1, r2, S1, S2;
            const double pi = 3.14;
            string s;
            Console.WriteLine("введите радиус r1 ");
            s = Console.ReadLine();
            r1 = double.Parse(s);

            Console.WriteLine("введите радиус r2 ");
            s = Console.ReadLine();
            r2 = double.Parse(s);

            S1 = pi * (r1 * r1);
            S2 = pi * (r2 * r2);
            Console.WriteLine("Площадь первого круга равна " + S1);
            Console.WriteLine("Площадь второго круга равна " + S2);
            Console.WriteLine("Внешний радиус окружности равен " + (S1 - S2));
            Console.ReadLine();
            
        }
    }
}
