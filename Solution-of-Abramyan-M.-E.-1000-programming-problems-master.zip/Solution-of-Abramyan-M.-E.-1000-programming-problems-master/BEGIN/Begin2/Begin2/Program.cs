﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    class Program
    {
        static void Main(string[] args)
        {
        int a, S;
        a = 3;
        S = a * a;
        Console.WriteLine("Площадь квадрата S= " + S);
        Console.ReadLine();
        }
    }

