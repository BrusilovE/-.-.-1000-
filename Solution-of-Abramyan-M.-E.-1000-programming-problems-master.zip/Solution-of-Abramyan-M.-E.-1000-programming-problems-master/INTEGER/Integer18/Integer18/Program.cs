﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer18
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            string str;
            Console.Write("введите число больше 999 = ");
            str = Console.ReadLine();
            a = int.Parse(str);
            Console.Write("число, соответствубщее разряду тысяч в записи числа = "
                + a / 1000 % 10);
            Console.ReadLine();
        }
    }
}
