﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer29
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b, c, k, s;
            Console.Write("даны целые положительные числа a = ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.Write("даны целые положительные числа b = ");
            b = Convert.ToInt32(Console.ReadLine());
            Console.Write("даны целые положительные числа c = ");
            c = Convert.ToInt32(Console.ReadLine());
            k = (a / c) * (b / c);           
            Console.WriteLine("количество квадратов, размещенных на прямоугольнике = " + k);
            s = a * b - k * (c * c);
            Console.Write("площадь незанятой части прямоугольника = " + s);
            Console.ReadLine();
        }
    }
}
