﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer19
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            string str;
            Console.Write("введите количество секунд с начала суток = ");
            str = Console.ReadLine();
            a = int.Parse(str);
            Console.Write("количество полных часов, прошедших с начала суток = "
                + (a/60)/60);
            Console.ReadLine(); 
        }
    }
}
