﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer10
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            string str;
            Console.Write("введите 3-х значное число = ");
            str = Console.ReadLine();
            a = int.Parse(str);
            Console.WriteLine("последняя цифра числа = " + a % 10);
            Console.WriteLine("средняя цифра числа = " + (a/10)%10);
            Console.ReadLine();
        }
    }
}
