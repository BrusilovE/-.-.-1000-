﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer17
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            string str;
            Console.Write("введите целое число A, больше 999 = ");
            str = Console.ReadLine();
            a = int.Parse(str);
            Console.WriteLine("число, соответствующую разряду сотен этого числа = " 
                + a / 100 % 10);
            Console.ReadLine();
        }
    }
}
