﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer9
{
    class Program
    {
        static void Main()
        {
            int a;
            string str;
            Console.Write("введите трехзначное число = ");
            str = Console.ReadLine();
            a = int.Parse(str);
            Console.WriteLine("первая цифра данного числа = " + a/100);
            Console.ReadLine();
        }
    }
}
