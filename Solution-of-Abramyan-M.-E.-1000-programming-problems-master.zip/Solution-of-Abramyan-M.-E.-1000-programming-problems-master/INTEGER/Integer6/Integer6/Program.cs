﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer6
{
    class Program
    {
        static void Main()
        {
            int a;
            string s;
             Console.WriteLine("Введиет двузначное число ");
             s = Console.ReadLine();
             a = int.Parse(s);                  
             Console.WriteLine("десятки = "+ (a/10) + ", единицы = " + a % 10);
            Console.ReadLine();

        }
    }
}
