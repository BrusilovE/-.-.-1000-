﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer11
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            string str;
            Console.WriteLine("введите трехзначное число ");
            str = Console.ReadLine();
            a = int.Parse(str);
            Console.WriteLine("Сумма = " + ((a / 100) + (a / 10 % 10) + (a % 10)) + 
                ", произведение = " + ((a / 100) * (a / 10 % 10) * (a % 10)));
            Console.ReadLine();


        }
    }
}
