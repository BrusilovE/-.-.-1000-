﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace integer4
{
    class Program
    {
        static void Main()
        {
            int A, B;
            string s;
            Console.WriteLine("Введите целые полож-е числа A и B ");
            s = Console.ReadLine();
            A = int.Parse(s);
            s = Console.ReadLine();
            B = int.Parse(s);
            Console.WriteLine("Количество отрезков В, размещенных на отрезке А = "+ A / B);
            Console.ReadLine();


        }
    }
}
