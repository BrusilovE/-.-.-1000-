﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer20
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            string str;
            Console.Write("введите число секунд, прошедших  с начало суток = ");
            str = Console.ReadLine();
            a = int.Parse(str);
            Console.Write("количество полных минут, прошедших с начала суток = "
                + a / 60 );
            Console.ReadLine();

        }
    }
}
