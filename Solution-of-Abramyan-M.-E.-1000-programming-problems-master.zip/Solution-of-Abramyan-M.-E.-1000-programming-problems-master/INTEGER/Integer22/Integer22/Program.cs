﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer22
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            Console.Write("введите число секунд, прошедших с начала суток = ");            
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("пример = " + a % (60*60) );
            Console.ReadLine();

        }
    }
}
