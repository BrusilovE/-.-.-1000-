﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer14
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            string str;
            Console.Write("введите трехзначное число ");
            str = Console.ReadLine();
            a = int.Parse(str);
            Console.Write("полученное число = " + a % 10 
                + a/100 + a / 10 % 10);
            Console.ReadLine();
        }
    }
}
