﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer30
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, v;
            Console.Write("введите номер некоторого года = ");
            a = Convert.ToInt32(Console.ReadLine());
            v = (a / 100) % 100;
            Console.Write("столетие, соответсвующее номеру года = " + ++v);
            Console.ReadLine();
        }
    }
}
