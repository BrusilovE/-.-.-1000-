﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer12
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            string str;
            Console.WriteLine("введите трехначное число ");
            str = Console.ReadLine();
            a = int.Parse(str);
            Console.WriteLine("прочтенное исходное числа справа налево = " 
                + a%10 + ((a/10)%10) + a/100);
            Console.ReadLine();

        }
    }
}
