﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer24
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            Console.Write("введите целое число = ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.Write("номер дня недели = " + (a+3) % 7);
            Console.ReadLine();
        }
    }
}
