﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer28
{
    class Program
    {
        static void Main(string[] args)
        {
            int k, n;
            Console.Write("введите челое число в диапазоне 1-365 = ");
            k = Convert.ToInt32(Console.ReadLine());
            Console.Write("введите число лежащее в дипазоне 1-7 = ");
            n = Convert.ToInt32(Console.ReadLine());
            Console.Write("определить номер дня недели = " + (k + n) % 7);
            Console.ReadLine();
        }
    }
}
