﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer1
{
    class Program
    {
        static void Main(string[] args)
        {
            int L;
            string s;
            Console.Write("Введите рассояние L в сантиметрах = ");
            s = Console.ReadLine();
            L = int.Parse(s);            
            Console.Write("Количество полных метров равно " + L/100);
            Console.ReadLine();

        }
    }
}
