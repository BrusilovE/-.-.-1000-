﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Integer21
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;            
            Console.Write("введите кол-во секунд с начала суток = ");
            a = Convert.ToInt32(Console.ReadLine());
            Console.Write("количество секунд, прошедших с начала последней минуты = "
                + a % 60);
            Console.ReadLine();
        }
    }
}
