﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Boolean4
{
    class Program
    {
        static void Main(string[] args)
        {
            bool s, d;
            int a, b;
            Console.WriteLine("введите два целых числа ");
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());
            s = a > 2;
            d = b <= 3;
            Console.WriteLine("справедливо неравенство A > 2 {0} и B <= 3 {1} " ,
                s , d);
            Console.ReadLine();
        }
    }
}
