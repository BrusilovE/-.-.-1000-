﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Boolean7
{
    class Program
    {
        static void Main(string[] args)
        {
            bool s;
            int a, b, c;
            Console.WriteLine("введите три целых числа: ");
            a = Convert.ToInt32(Console.ReadLine());            
            b = Convert.ToInt32(Console.ReadLine());           
            c = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("A = {0}, B = {1}, C = {2}" , a, b, c);        
            s = (a < b) & (b < c);
            Console.WriteLine("Число B находится между числами A и C = " + s);
            Console.ReadLine();
        }
    }
}
