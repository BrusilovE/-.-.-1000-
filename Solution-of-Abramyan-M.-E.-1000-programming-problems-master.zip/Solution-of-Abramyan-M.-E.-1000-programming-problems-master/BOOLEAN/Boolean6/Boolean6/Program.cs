﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Boolean6
{
    class Program
    {
        static void Main(string[] args)
        {
            bool s;
            int A, B, C;            
            Console.WriteLine("введите три целых числа: A, B, C");
            A = Convert.ToInt32(Console.ReadLine());
            B = Convert.ToInt32(Console.ReadLine());
            C = Convert.ToInt32(Console.ReadLine());
            s = (A < B) & (B < C);            
            Console.WriteLine("Справедливо двойное неравенство A < B < C {0}", s);
            Console.ReadLine();
        }
    }
}
