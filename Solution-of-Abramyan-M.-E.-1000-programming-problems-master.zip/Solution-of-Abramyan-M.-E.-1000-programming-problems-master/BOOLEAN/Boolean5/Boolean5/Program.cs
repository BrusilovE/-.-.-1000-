﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Boolean5
{
    class Program
    {
        static void Main(string[] args)
        {
            bool s, d;
            int a, b;
            Console.WriteLine("введите два целых числа A, B: ");
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());
            s = a >= 0;
            d = b < -2;
            Console.WriteLine("Справедливо неравенство A >= 0 {0} или B < –2 {1}" , s, d);
            Console.ReadLine();
        }
    }
}
